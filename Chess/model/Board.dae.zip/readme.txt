-- 3dvia.com   --

The zip file Board.dae.zip contains the following files :
- readme.txt
- Board.dae
- file_/C_/3D Work/Personal/chess_Simple/data/Board_Diff.jpg


-- Model information --

Model Name : Chess Board
Author : jdelrio
Publisher : jdelrio

You can view this model here :
http://www.3dvia.com/content/874F68BD8FA1B385
More models about this author :
http://www.3dvia.com/jdelrio


-- Attached license --

A license is attached to the Chess Board model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
