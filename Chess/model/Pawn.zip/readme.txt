-- 3dvia.com   --

The zip file chess.obj.zip contains the following files :
- readme.txt
- chess.obj
- chess.mtl


-- Model information --

Model Name : chess
Author : MaDLiNe
Publisher : MaDLiNe

You can view this model here :
http://www.3dvia.com/content/70365466784A5C6E
More models about this author :
http://www.3dvia.com/MaDLiNe


-- Attached license --

A license is attached to the chess model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution-NonCommercial-ShareAlike 2.5
Detailed license : http://creativecommons.org/licenses/by-nc-sa/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
