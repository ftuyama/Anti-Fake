-- 3dvia.com   --

The zip file White_King.dae.zip contains the following files :
- readme.txt
- White_King.dae
- file_/C_/3D Work/Personal/chess_Simple/data/WhiteKing_Diff.jpg


-- Model information --

Model Name : White King
Author : jdelrio
Publisher : jdelrio

You can view this model here :
http://www.3dvia.com/content/EEC610E4F6C8DAEC
More models about this author :
http://www.3dvia.com/jdelrio


-- Attached license --

A license is attached to the White King model and all related media.
You must agree with this licence before using the enclosed media.

License : Attribution License 2.5
Detailed license : http://creativecommons.org/licenses/by/2.5/

The licenses used by 3dvia are based on Creative Commons Licenses.
More info: http://creativecommons.org/about/licenses/meet-the-licenses
